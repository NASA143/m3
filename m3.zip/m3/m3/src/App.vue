
<template>
<div>
<nav class="navbar">
<router-link to="/">Interactive Boards</router-link>
<div>
<router-link to="/boards/public">Public</router-link>
<router-link v-if="auth" to="/boards">My</router-link>
<button v-if="auth" @click="logout" class="btn btn-outline">Logout</button>
</div>
</nav>
<router-view/>
</div>
</template>

<script setup>
import { useAuthStore } from './stores/auth'
const store = useAuthStore()
const auth = store.isAuthenticated
const logout = ()=>store.logout()
</script>
