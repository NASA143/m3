
<template>
<div class="container">
<h1>My Boards</h1>
</div>
</template>
