
<template>
<div class="container">
<h1>Public Boards</h1>
</div>
</template>
