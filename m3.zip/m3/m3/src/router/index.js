
import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes=[
{path:'/',redirect:'/boards/public'},
{path:'/login',component:()=>import('@/pages/LoginPage.vue'),meta:{guest:true}},
{path:'/boards',component:()=>import('@/pages/MyBoardsPage.vue'),meta:{auth:true}},
{path:'/boards/public',component:()=>import('@/pages/PublicBoardsPage.vue')}
]

const router=createRouter({history:createWebHistory(),routes})

router.beforeEach((to,from,next)=>{
const auth=useAuthStore()
if(to.meta.auth&&!auth.isAuthenticated) next('/login')
else next()
})

export default router
