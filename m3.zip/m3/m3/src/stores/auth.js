
import { defineStore } from 'pinia'
import api from '@/services/api'

export const useAuthStore=defineStore('auth',{
state:()=>({user:null,token:localStorage.getItem('token')}),
getters:{isAuthenticated:s=>!!s.token},
actions:{
async login(email,password){
const {data}=await api.post('/auth/login',{email,password})
this.token=data.token
this.user=data.user
localStorage.setItem('token',data.token)
},
logout(){
this.token=null
this.user=null
localStorage.removeItem('token')
}
}
})
