
import { defineStore } from 'pinia'
import api from '@/services/api'

export const useBoardsStore=defineStore('boards',{
state:()=>({myBoards:[],publicBoards:[],loading:false}),
actions:{
async fetchMyBoards(){
this.loading=true
const {data}=await api.get('/boards')
this.myBoards=data
this.loading=false
},
async fetchPublicBoards(){
this.loading=true
const {data}=await api.get('/boards/public')
this.publicBoards=data
this.loading=false
}
}
})
